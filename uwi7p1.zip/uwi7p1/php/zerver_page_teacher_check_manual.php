<?php

include 'zerver_entrance.php';

session_start();

// error_reporting(0);
$email = $_SESSION["curr_email_user"];
$id = $_POST["question_id"];
$stud_id = $_POST["answer_id"];
$grade = $_POST["grade"];
$corr = $_POST["corr_param"];
$inco = $_POST["inco_param"];
$curr = $_POST["current_checker"];
$curr_grad = strpos($curr, "<!@#%GRADES$%^>");
$curr_corr = strpos($curr, "<!@#CORRECT$%^>");
$curr_inco = strpos($curr, "<!@#INCORRECT$%^>");
$curr_enum = strpos($curr, "<!@#ENUMERATE$%^>");
$str_grad = "";
$str_corr = "";
$str_inco = "";
$str_enum = "";
for($x = 15; $x < $curr_corr; $x++){
  $str_grad .= $curr[$x];
}
for($x = $curr_corr + 15; $x < $curr_inco; $x++){
  $str_corr .= $curr[$x];
}
for($x = $curr_inco + 17; $x < $curr_enum; $x++){
  $str_inco .= $curr[$x];
}
for($x = $curr_enum + 17; $x < strlen($curr); $x++){
  $str_enum .= $curr[$x];
}
$str_corr .= "<&**>";
$str_inco .= "<&**>";
$str_grad .= "<&**>".$grade;
if($corr != ""){
  for($x = 0; $x < count($corr); $x++){
    $str_corr .= "<&*>".$corr[$x];
  }
}
if($inco != ""){
  for($x = 0; $x < count($inco); $x++){
    $str_inco .= "<&*>".$inco[$x];
  }
}


$output = str_replace("'", "''","<!@#%GRADES$%^>".$str_grad."<!@#CORRECT$%^>".$str_corr."<!@#INCORRECT$%^>".$str_inco."<!@#ENUMERATE$%^>".$str_enum);

// echo $output;

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  
    $sql = "UPDATE `created_questions` SET `checking_param` = '$output' WHERE `question_id`='$id' AND `owner_teacher` = '$email'";
  
    // Prepare statement
    $stmt = $conn->prepare($sql);
  
    // execute the query
    $stmt->execute();

    try {
      $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
      // set the PDO error mode to exception
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
      $sql = "UPDATE student_answers SET grades = '$grade', checked = '1' WHERE answer_id='$stud_id'";
    
      // Prepare statement
      $stmt = $conn->prepare($sql);
    
      // execute the query
      $stmt->execute();
  
      echo "CHECKED MANUALLY";
    
    } catch(PDOException $e) {
      echo $sql . "<br>" . $e->getMessage();
    }
  
  } catch(PDOException $e) {
    echo $sql . "<br>" . $e->getMessage();
  }
  
  $conn = null;

?>