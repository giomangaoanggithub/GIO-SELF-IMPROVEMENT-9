<?php

include 'zerver_entrance.php';

session_start();

error_reporting(0);

$email = $_SESSION["curr_email_user"];

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $conn->prepare("SELECT T1.question_id, all_ans, (all_ans - checked_ans) as checked_ans, owner_teacher FROM ((SELECT question_id, COUNT(question_id) as all_ans FROM student_answers GROUP BY question_id) AS T1 LEFT JOIN (SELECT question_id, COUNT(checked) as checked_ans FROM student_answers WHERE checked = 0 GROUP BY question_id) AS T2 ON T1.question_id = T2.question_id) LEFT JOIN created_questions ON T1.question_id = created_questions.question_id WHERE owner_teacher = '$email';");
    $stmt->execute();
  
    // set the resulting array to associative
    $result = $stmt->FetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode($result);

  } catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
  }
  $conn = null;

?>