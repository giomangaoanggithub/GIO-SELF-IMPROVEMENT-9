<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/page_teacher.css">
    <script src="https://code.jquery.com/jquery-3.6.4.js"
        integrity="sha256-a9jBBRygX1Bh5lt8GZjXDzyOB+bWve9EiO7tROUtj/E=" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <title>Essay Speed Checker</title>
</head>

<body>
    <div id="overlay" onclick="off()"></div>
    <div id="delete_r-space">
        <div id="delete_r-modal">
            <div id="delete_r-title">Are you sure? You're going to delete this room? </div>
            <div id="delete_r-btn"><button id="r-delete">YES!</button><img src="images/loading.gif" alt=""
                    style="display: none; height: 30px" id="delete_r_loady"></div>
        </div>
    </div>
    <div id="company_src-space">
        <div id="company_src-modal">
            <div id="company_src-title">Search Company</div>
            <div>
                <label for="search-company">Search Company Name:</label><br><input type="text" id="search-company"><br>
                <label for="company-code">Company Code:</label><br><input type="text" id="company-code">
            </div>
            <div id="company_src-btn"><button id="accept-company">Apply!</button><img src="images/loading.gif" alt=""
                    style="display: none; height: 30px" id="apply_company_loady"></div>
        </div>
    </div>
    <div id="company_queue-space">
        <div id="company_queue-modal">
            <div id="company_queue-title">Please Wait for the admin to accept your application.</div>
            <div><button id="cancel_company-btn">Cancel</button></div>
        </div>
    </div>
    <div id="loading-space">
        <div id="loading-modal">
            <div id="loading-atlarge"><img src="images/loading.gif" alt=""></div>
        </div>
    </div>
    <div id="teacher-navbar">
        <div id="company-title" class="col-12">
        </div>
        <div id="teacher-details" class="col-12">
            <div><img src="images/profile.png" id="profile-pic" alt=""></div>
            <div id="vl"></div>
            <div id="profile-name-email">Name: <br> Email: <br> Role: </div>
        </div>
        <div id="teacher-sub-bar" class="col-12">
            <div class="teacher-sub-bar-tab" id="teacher-sub-bar-tab1">Room</div>
            <div class="teacher-sub-bar-tab" id="teacher-sub-bar-tab1-1"><i class="material-icons">door_front</i></div>
            <div class="teacher-sub-bar-tab" id="teacher-sub-bar-tab2">Create</div>
            <div class="teacher-sub-bar-tab" id="teacher-sub-bar-tab2-2"><i class="material-icons">add_circle</i></div>
            <div class="teacher-sub-bar-tab" id="teacher-sub-bar-tab3">Essays & Grades</div>
            <div class="teacher-sub-bar-tab" id="teacher-sub-bar-tab3-3"><i
                    class="material-icons">assignment_turned_in</i></div>
        </div>
        <div id="teacher-rooms" class="col-12">
            <div id="list-of-rooms-appli" class="col-12">
                <div>
                    <div id="table-rooms">
                        <table>
                            <thead id="thead-lor"></thead>
                            <tbody id="tbody-lor">
                                <tr>
                                    <td></td>
                                    <td></td>
                                    <td><img src="images/loading.gif" alt="" style="height: 30px"></td>
                                    <td></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div id="room-maker">
                        <label for="create-room">Room:</label><input type="text" id="create-room">
                        <label for="code-room">Room Code:</label><input type="text" id="code-room">
                        <button id="create-room-btn">CREATE ROOM</button>
                        <img src="images/loading.gif" alt="" style="height: 30px; display: none;" id="create-room-load">
                    </div>
                    <div id="room-sorter">
                        <label for="find-room">Search Room:</label><input type="text" id="find-room">
                    </div>

                </div>
                <div>
                    <div id="table-newstud">
                        <table>
                            <thead id="thead-newstud">
                            </thead>
                            <tbody id="tbody-newstud">
                                <tr>
                                    <td></td>
                                    <td></td>
                                    <td><img src="images/loading.gif" alt="" style="height: 30px"></td>
                                    <td></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div id="newstud-sorter">
                        <div><label for="find-newstud">Student: </label><input type="text" id="find-newstud"></div>
                        <div><label for="find-newstudroom">Room: </label><input type="text" id="find-newstudroom"></div>

                    </div>

                </div>



            </div>
        </div>
        <div id="teacher-create" class="col-12">
            <div>
                <div id="room-title-create-q" class="col-12">Room: </div>
                <div id="table-cq">
                    <table>
                        <thead id="thead-cq"></thead>
                        <tbody id="tbody-cq"></tbody>
                    </table>
                </div>
                <div id="create-q-area"><label for="create-q" id="create-q-label">Create Question: </label><br><textarea
                        id="create-q" rows="4" cols="60"></textarea><br>
                    <div>
                        <label for="type-essay-q" id="type-q-label">Type of Essay Question: </label><br><select name=""
                            id="type-essay-q" onchange="type_q()">
                            <option id="create-q-r" value="response" data-toggle="tooltip"
                                title="Who?, What?, and Where?">response</option>
                            <option id="create-q-fr" value="factual-recall" data-toggle="tooltip"
                                title="Ex: list down and explain the..., Enumerate the... and explain, etc.">
                                factual-recall</option>
                        </select><br><label for="list-important" id="topic-q-label">Topics:</label><br><textarea
                            id="list-important" rows="4" cols="60"></textarea><br>
                        <label for="hps-input">Highest possible score:</label><br>
                        <input type="number" value="20" min="10" id="hps-input"><br><label for="due-input">Due
                            Date:</label><br>
                        <input type="datetime-local" value="<?php echo date('Y-m-d', strtotime(' + 4 days')); ?>T23:59"
                            name="" id="due-input">
                    </div>
                    <br>
                    <button id="submit-q" onclick="submit_question()">CREATE</button><button
                        id="resubmit-q">UPDATE</button><button id="cancel-q-up"
                        onclick="cancel_edit_question()">CANCEL</button><img id="submit-q-loading"
                        src="images/loading.gif" alt="" style="height: 30px; display: none;">
                </div>
            </div>
        </div>
        <div id="teacher-grades" class="col-12">
            <div id="fetch-checking-items">
                <table>
                    <thead>
                        <tr>
                            <th style="width: 5%">student</th>
                            <th style="width: 5%">status</th>
                            <th style="width: 40%">question</th>
                            <th style="width: 40%">student answer<i class="material-icons" style="font-size: 20px"
                                    data-toggle="tooltip" data-placement="right"
                                    title="You can highlight incorrect context and grade it.">help</i></th>
                            <th style="width: 10%">action</th>
                        </tr>
                    </thead>
                    <tbody id="tbody-se">
                    </tbody>
                </table>
            </div><br>
            <div id="fetch-students-grades">
                <div id="innerview-of-stud-grades">
                    <table>
                        <thead id="innerview-of-stud-grades-th">
                            <tr>
                                <th style="color: #727968;">classroom</th>
                                <th style="color: #727968;">question and answer</th>
                                <th style="color: #727968;">grade</th>
                            </tr>
                        </thead>
                        <tbody id="grades-innerview">
                            <tr>
                                <td></td>
                                <td>Please pick a student...</td>
                                <td></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div id="list-of-students">
                    <table>
                        <thead>
                            <tr>
                                <th style="width: 20%">profile</th>
                                <th style="width: 80%">name</th>
                            </tr>
                        </thead>
                        <tbody id="grades-students">
                            <tr>
                                <td></td>
                                <td><img src="images/loading.gif" alt="" style="height: 30px"></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <script src='js/page_teacher.js'></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous">
    </script>
</body>

</html>